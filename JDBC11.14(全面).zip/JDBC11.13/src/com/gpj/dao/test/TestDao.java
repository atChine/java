package com.gpj.dao.test;

import com.gpj.dao.dao.NewsDao;
import com.gpj.jdbc.druid.News;
import org.junit.Test;

import java.util.List;

/**
 * @ClassName: TestDao
 * @Description: TODO
 * @Author: 高举
 * @Date: 2021/11/14 20:55
 * @URL：https://github.com/GaoHaiNB
 */
public class TestDao {
    //测试NewsDao对News表的CRUD操作
    @Test
    public void testNews(){
        NewsDao newsDao = new NewsDao();
        //1、查询
        List<News> list = newsDao.queryMulti("select * from news", News.class, null);
        System.out.print("===============查询多行结果=================");
        for (News news : list) {
            System.out.print(news);
        }
        //2.查询单行记录

        News news = newsDao.querySingle
                ("select * from news where id=?", News.class, 1);
        System.out.println();
        System.out.print("===============查询单行结果=================");
        System.out.println(news);
        //查询单个结果
        System.out.println("===============查询单个结果=================");
        Object o = newsDao.queryScalar("select name from news where id=?",1);
        System.out.println(o);

        //插入
        System.out.print("===============插入=================");
        int update = newsDao.update("insert into news values(?,?)",5,"王冰");
        System.out.println("生效了"+update+"行");


    }
}
