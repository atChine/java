package com.gpj.dao.domain;

/**
 * @ClassName: News
 * @Description: TODO
 * @Author: 高举
 * @Date: 2021/11/14 16:16
 * @URL：https://github.com/GaoHaiNB
 */
public class News {
    private Integer id;
    private String name;

    public News() {
    }

    public News(Integer id, String name) {
        this.id = id;
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "\nNews{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }
}
