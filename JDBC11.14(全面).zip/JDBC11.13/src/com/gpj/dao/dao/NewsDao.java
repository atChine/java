package com.gpj.dao.dao;

import com.gpj.jdbc.druid.News;

/**
 * @ClassName: NewsDao
 * @Description: TODO
 * @Author: 高举
 * @Date: 2021/11/14 20:54
 * @URL：https://github.com/GaoHaiNB
 */
public class NewsDao extends BasicDao<News>{

}
