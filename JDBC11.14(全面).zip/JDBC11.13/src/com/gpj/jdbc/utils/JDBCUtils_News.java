package com.gpj.jdbc.utils;

import org.junit.Test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @ClassName: JDBCUtils_News
 * @Description: TODO
 * @Author: 高举
 * @Date: 2021/11/13 17:01
 * @URL：https://github.com/GaoHaiNB
 */
public class JDBCUtils_News {
    @Test
    public void testDML(){
        //1.得到鏈接
        Connection connection = null;
        //2.sql語句
        String sql="update news set name=? where id=?";
        //3.創建PreparedStatement的對象
        PreparedStatement preparedStatement =null;
        try {
            connection = JDBCUtils.getConnection();
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,"小冰冰");
            preparedStatement.setInt(2,2);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
           e.printStackTrace();
        } finally {
            JDBCUtils.close(null,preparedStatement,connection);
        }
    }
    @Test
    public void testDML02(){
        //1.得到鏈接
        Connection connection = null;
        //2.sql語句

        String sql="update student set sum=sum-100 where id=1";
        String sql2="update student set sum=sum+100 where id=2";

        //3.創建PreparedStatement的對象
        PreparedStatement preparedStatement =null;
        try {
            connection = JDBCUtils.getConnection();
            connection.setAutoCommit(false);//開啓事務
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.executeUpdate();

            

            preparedStatement = connection.prepareStatement(sql2);
            preparedStatement.executeUpdate();

            connection.commit();
        } catch (SQLException e) {
            System.out.println("執行發生了異常");
            try {
                connection.rollback();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        } finally {
            JDBCUtils.close(null,preparedStatement,connection);
        }
    }
}
