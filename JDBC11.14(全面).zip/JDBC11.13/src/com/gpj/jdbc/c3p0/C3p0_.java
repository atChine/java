package com.gpj.jdbc.c3p0;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.hamcrest.Condition;
import org.junit.Test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

/**
 * @ClassName: C3p0_
 * @Description: TODO
 * @Author: 高举
 * @Date: 2021/11/14 9:33
 * @URL：https://github.com/GaoHaiNB
 */
public class C3p0_ {
    @Test
    //使用jar包
    public void testC3P0_01() throws Exception {
        //1.创建数据源对象
        ComboPooledDataSource comboPooledDataSource = new ComboPooledDataSource();
        //2.通过配置文件，获取相关信息
        Properties properties = new Properties();
        properties.load(new FileInputStream("src\\mysql.properties"));
        String user = properties.getProperty("user");
        String password = properties.getProperty("password");
        String url = properties.getProperty("url");
        String driver = properties.getProperty("driver");

        //给数据源 comboPooledDataSource 设置相关的参数
        comboPooledDataSource.setDriverClass(driver);
        comboPooledDataSource.setJdbcUrl(url);
        comboPooledDataSource.setUser(user);
        comboPooledDataSource.setPassword(password);

        //设置数据源的连接数（初始化）
        comboPooledDataSource.setInitialPoolSize(10);
        comboPooledDataSource.setMaxPoolSize(50);
        //测试连接池的效率
        long start = System.currentTimeMillis();
        for (int i = 0; i < 5000; i++) {
            Connection connection = comboPooledDataSource.getConnection();//连接数据库
            connection.close();
        }
        long end = System.currentTimeMillis();
        System.out.println("C3P0耗时= "+(end-start));//C3P0耗时= 365
    }
    @Test
    //2.使用配置文件
    public void testC3P0_02() throws SQLException {
        ComboPooledDataSource comboPooledDataSource = new ComboPooledDataSource("hello");
        long start = System.currentTimeMillis();
        for (int i = 0; i < 5000000; i++) {
            Connection connection = comboPooledDataSource.getConnection();
            connection.close();
        }
        long end = System.currentTimeMillis();
        System.out.println("C3P0耗时= "+(end-start));//C3P0耗时= 20792
    }
}
