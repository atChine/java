package com.gpj.jdbc;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;

/**
 * @ClassName: PerparedStatement
 * @Description: TODO
 * @Author: 高举
 * @Date: 2021/11/13 14:22
 * @URL：https://github.com/GaoHaiNB
 */
public class PreparedStatement {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.print("請輸入id：");
        String id = scanner.nextLine();
        System.out.print("請輸入name：");
        String name = scanner.nextLine();

        Properties properties = new Properties();
        properties.load(new FileInputStream("src\\mysql.properties"));

        String user = properties.getProperty("user");
        String password = properties.getProperty("password");
        String driver = properties.getProperty("driver");
        String url = properties.getProperty("url");

        Class.forName(driver);
        Connection connection = DriverManager.getConnection(url, user, password);

        String sql = "select id,name from news where id=? and name=?";
        java.sql.PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1,id);
        preparedStatement.setString(2,name);

        ResultSet resultSet = preparedStatement.executeQuery();
        if(resultSet.next()){
            System.out.println("登錄成功");
        }else {
            System.out.println("登錄失敗");
        }

    }
}
