package com.gpj.jdbc.druid;

import org.junit.Test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * @ClassName: JDBCUtilsByDruid_test
 * @Description: TODO
 * @Author: 高举
 * @Date: 2021/11/14 10:50
 * @URL：https://github.com/GaoHaiNB
 */
public class JDBCUtilsByDruid_test {
    @Test
    public void test() {
        Connection connection = null;
        ResultSet set=null;
        //2.sql語句
        String sql = "select * from news";
        //3.創建PreparedStatement的對象
        PreparedStatement preparedStatement = null;
        ArrayList<News> list = new ArrayList<>();
        try {
            connection = JDBCUtilsByDruid.getConnection();
            preparedStatement = connection.prepareStatement(sql);
            set=preparedStatement.executeQuery();
            while (set.next()){
                int id = set.getInt("id");
                String name = set.getString("name");
                list.add(new News(id,name));
            }
            System.out.println(list.toString());

        } catch (
                SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtilsByDruid.close(null, preparedStatement, connection);
        }
    }
}
