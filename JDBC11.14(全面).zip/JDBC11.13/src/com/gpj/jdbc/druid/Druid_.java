package com.gpj.jdbc.druid;

import com.alibaba.druid.pool.DruidDataSourceFactory;
import org.junit.Test;

import javax.sql.DataSource;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.util.Properties;

/**
 * @ClassName: Druid_
 * @Description: TODO
 * @Author: 高举
 * @Date: 2021/11/14 10:19
 * @URL：https://github.com/GaoHaiNB
 */
public class Druid_ {
    @Test
    public void testDruid_01() throws Exception {
        Properties properties = new Properties();
        properties.load(new FileInputStream("src\\druid.properties"));
        //创建一个指定参数的连接池,Druid的连接池
        DataSource dataSource =
                DruidDataSourceFactory.createDataSource(properties);
        long start = System.currentTimeMillis();
        for (int i = 0; i < 5000000; i++) {
            Connection connection = dataSource.getConnection();
            connection.close();
        }
        long end = System.currentTimeMillis();
        System.out.println("Druid耗时= "+(end-start));//Druid耗时= 1217

    }
    @Test
    public void testDruid_02(){

    }
}
