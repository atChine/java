package com.gpj.jdbc.druid;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.junit.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName: DBUtils
 * @Description: TODO
 * @Author: 高举
 * @Date: 2021/11/14 16:52
 * @URL：https://github.com/GaoHaiNB
 */
public class DBUtils {
    @Test
    public void testDBUtils_01() throws SQLException {
        Connection connection = JDBCUtilsByDruid.getConnection();
        QueryRunner queryRunner = new QueryRunner();
        String sql = "select * from news";
        List<News> list = queryRunner.query(connection, sql, new BeanListHandler<>(News.class));
        for (News news:list){
            System.out.print(news);
        }
        JDBCUtilsByDruid.close(null,null,connection);
    }
}
