package com.gpj.jdbc;

import com.mysql.jdbc.Driver;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class Jdbc01 {
    public static void main(String[] args) throws SQLException {
        //1,注册驱动
        Driver driver = new Driver();

        //2.定义连接的方式
        String url = "jdbc:mysql://localhost:3306/gpj_01";
        //3.将用户名和密码放在properties中
        Properties properties = new Properties();
        properties.setProperty("user", "root");
        properties.setProperty("password", "123");
        Connection connect = driver.connect(url, properties);

        //3.执行sql语句
        String sql = "delete from actor where id=1";
        Statement statement = connect.createStatement();
        int rows = statement.executeUpdate(sql);

        System.out.println(rows > 0 ? "成功" : "失败");
        //4.资源关闭
        statement.close();
        connect.close();
    }
}
