package src.com.Exercise02;

//������
public class Listcontroller {


	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		linkList list = new linkList();
		int[] numlist = {4,5,13,16,2,7,15,11,32,24};
		for (int i=0;i<10;i++){
			node<Integer> n = new node<Integer>(numlist[i]);
			list.insert(n, i);
		}
		
		list.printList();
		int pos = list.find(13);
		if (pos != -1){
			System.out.println("λ��Ϊ"+pos);
		}
		//����Ԫ��50
		node<Integer> n1 = new node<Integer>(50);
		list.insert(n1, 5);
		list.printList();
		//ɾ��Ԫ��7
		list.remove(7);
		list.printList();
	}
}